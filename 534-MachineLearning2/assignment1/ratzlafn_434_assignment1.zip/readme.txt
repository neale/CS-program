Neale Ratzlaff
Regression.py
CS 434 assignment 1


Usage: 
This program was written in python 2.7, using the standard library, numpy, and matplotlib

Matplotlib is currently commented out to suppress output for the ENGR servers. 

There is a graphical output is you want it. Just uncomment the relevant lines in the plotting function,
and uncomment the matplotlib includes. 

Run using: python regression.py


