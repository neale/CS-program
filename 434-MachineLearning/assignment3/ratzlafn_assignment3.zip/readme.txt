Neale Ratzlaff
Implementation assignment 3
knn.py
dt.py

Both programs were developed with python2.7, and are runnable with python <filename>
Graphical output using matplotlib is contained, but supressed for testing. 

dt.py is not complete sue to capstone project and a complete mismanagement of time. 
