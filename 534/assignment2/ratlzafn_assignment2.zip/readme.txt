//Neale Ratzlaff
17 April 2016
CS 434 Assignment 2

The code was created with python 2.7, and it should be able to run using "python2 logistic_regression.py"

In order to see the graphical outputs that have been commented out. Simply look at the ./images folder contained. Or Uncomment the appropriate code

The latex file is provided, but the PDF should suffice
